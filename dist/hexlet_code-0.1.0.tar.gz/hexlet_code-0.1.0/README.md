### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvgenyAleksov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EvgenyAleksov/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/da1d813750c6909348f7/maintainability)](https://codeclimate.com/github/EvgenyAleksov/python-project-49/maintainability)


Step 5

[![asciicast](https://asciinema.org/a/yziIELOXd2UKsSf2kejL6DrDi.svg)](https://asciinema.org/a/yziIELOXd2UKsSf2kejL6DrDi)


Step 6

[![asciicast](https://asciinema.org/a/enJSpsEAVdWmwPUTWyEEcFXXT.svg)](https://asciinema.org/a/enJSpsEAVdWmwPUTWyEEcFXXT)


Step 7

[![asciicast](https://asciinema.org/a/Sn307pUZ00jLQeHPggeu3EO35.svg)](https://asciinema.org/a/Sn307pUZ00jLQeHPggeu3EO35)